import React from 'react'

export default function Home() {
    return (
        <div>
            
            <h1>Dobrodošli na našu online IT prodavnicu!</h1>
        </div>
    )
}
