
export const SERVER_URL = 'https://localhost:4000'